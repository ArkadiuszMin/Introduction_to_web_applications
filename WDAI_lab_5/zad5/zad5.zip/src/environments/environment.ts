// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDw-DOv4vRltJ5JXJ9dOS8ROQyGy7S-Y-I",
    authDomain: "students-17700.firebaseapp.com",
    projectId: "students-17700",
    storageBucket: "students-17700.appspot.com",
    messagingSenderId: "802109861468",
    appId: "1:802109861468:web:ca9aa28c2abbf09fb94099",
    measurementId: "G-7BPXZQR0J5"
  }
};


