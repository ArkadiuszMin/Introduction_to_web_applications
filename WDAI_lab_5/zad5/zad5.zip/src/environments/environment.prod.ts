export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDw-DOv4vRltJ5JXJ9dOS8ROQyGy7S-Y-I",
    authDomain: "students-17700.firebaseapp.com",
    projectId: "students-17700",
    storageBucket: "students-17700.appspot.com",
    messagingSenderId: "802109861468",
    appId: "1:802109861468:web:ca9aa28c2abbf09fb94099",
    measurementId: "G-7BPXZQR0J5"
  }
};