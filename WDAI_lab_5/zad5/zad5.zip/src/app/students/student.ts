export class Student {
  constructor(
    public key: number,
    public name: string,
    public age: number
  ){}
}
