import { ITrip } from "./itrip";

export interface ITripsData {
    tripsData: Array<ITrip>
}
